# sAI -- protected build. Licensed software, not open source: copying, decompiling,
# modifying or redistributing this file is prohibited by the sAI license.
from sai_guard import _load
_load('ui.renderer', globals(), 'eGT7NyA8oXRgvMEnYrrheEk3EHVHyWs9ysRZRE2Sxx51bD7a1vRyShpjUuj8hOTLPOjV/f/4F56gPhkQiyxCkUCbyojyoH2P6EIxnIwGgOEqzdIlX2NkkQR24aefLPL8zf8JWtMJ+TiHJLvPIdZ8aPGKBxxdr1nKomOQI6iSgLIIfpk=')
