# sAI -- protected build. Licensed software, not open source: copying, decompiling,
# modifying or redistributing this file is prohibited by the sAI license.
from sai_guard import _load
_load('tools', globals(), 'aI4nJV9cajdpfvQTT6Hg37auYHhaJ4MxeTC4BUJLSHHN+0uTnpGk6Tt2HRlFZPPMv+GKgBnvvZB0U2CqcACW5VYXq8eyZZju8xBcghRb5scn73FORLT1b9NiZwR/BpNnLLV8235MSEGGWAGJf27t9Cyf9IseoO3NICnpfgBoa+BJcbQfhls=')
