"""`python -m sai_guard ...` -- the user's side of licensing (shipped as sai_guard/__main__.py)."""
import sys

from sai_guard import LicenseError, activate, find_license, license_path, machine_code

USAGE = """usage:
  python -m sai_guard machine-id          print this computer's code (send it with your access request)
  python -m sai_guard activate [FILE]     install the license from your approval email"""


def main(args):
    try:
        if args == ["machine-id"]:
            print(machine_code())
        elif args[:1] == ["activate"]:
            if len(args) > 1:
                text = open(args[1], encoding="utf-8").read()
            else:
                print("Paste the license from your email (everything from { to }), then press Enter on an empty line:")
                # Read until a whole license has arrived (pasting the entire email is fine),
                # or two empty lines in a row.
                lines, blank = [], 0
                for line in sys.stdin:
                    lines.append(line)
                    blank = blank + 1 if not line.strip() else 0
                    if (line.strip().endswith("}") and find_license("".join(lines))) or blank >= 2:
                        break
                text = "".join(lines)
            path = activate(text)
            print(f"✓ License installed at {path}. Run `sai` to start.")
        else:
            print(USAGE)
            return 2
    except LicenseError as e:
        print(f"✗ {e}", file=sys.stderr)
        return 1
    return 0


sys.exit(main(sys.argv[1:]))
