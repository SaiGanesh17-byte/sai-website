# sAI -- protected build. Licensed software, not open source: copying, decompiling,
# modifying or redistributing this file is prohibited by the sAI license.
from sai_guard import _load
_load('core', globals(), 'fjklIw4FECyhHH5JOD4evx4+gvOQ4u8pFyTZOdkSq/94m1t785pTxlUktLkatL8DKALv0iPXHzTLpmeVDndB2/lSucFMoUTyYA8B2EMHlbVfwqYQ8NPF+/nfP5stJTEPNrtkR90BKQPTd3uI/1LCkNU3mQCMlE0HSPlBrgeXE7KzPunSMg==')
