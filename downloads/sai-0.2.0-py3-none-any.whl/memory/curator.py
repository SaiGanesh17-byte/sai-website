# sAI -- protected build. Licensed software, not open source: copying, decompiling,
# modifying or redistributing this file is prohibited by the sAI license.
from sai_guard import _load
_load('memory.curator', globals(), 'AC5XbXqDzCLpRkG9/9/5oAEmbhadYOB+L3OKtgNTcI9LJGC3pUOwWJwrGn72bKi7UwY0Yi1J1Yw7GwDiZa0+O4LDoEhC0UgNBkKqpGGjKsRR8tE4WQ+dHIdW1877LBQDXNZRvYLbNwszy/OMnCEh+CeQRpI+n5gATy08zxP2yJZL0agw1m4=')
