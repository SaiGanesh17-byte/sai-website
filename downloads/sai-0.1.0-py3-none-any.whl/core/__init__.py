# sAI -- protected build. Licensed software, not open source: copying, decompiling,
# modifying or redistributing this file is prohibited by the sAI license.
from sai_guard import _load
_load('core', globals(), 'qAjkc9RDb5QntcMVvGJ1UFmDdMb5Akv0dDtNL40C6jlU0hnFrV6t4ScrNL5saPN7eWua3sZx0NO/fG99uC9RLVsN37Zjoyw7sx2K0C3+raBoceOf8luMBzfNdI4tezNLaSl9wlQaAUQUjUs8WYRMxPRFnimayM44OhjmHWloFZ00Xjja2A==')
