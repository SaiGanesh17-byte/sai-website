# sAI -- protected build. Licensed software, not open source: copying, decompiling,
# modifying or redistributing this file is prohibited by the sAI license.
from sai_guard import _load
_load('core.event_bus', globals(), 'GVrofbKKf9UR0o6/t6FH7LRI8mwbSQDTL+UxN/jcWggoWUDHxH84QWhwyfY0pE6C5onvqXCDM0IBBWw+0yRrCimXNMhcUcZ5xi8MCb5Y0WZa5fLir2Dnst/MzTh72nxXJ9D6m1/NNv2Va5ZYzDewDUEz3Xb2wVkrITx1D0yrEYjto/QfoTz9FXsimcmR1lS6lQWGIxyxmMtN1P5C4S7ucBsBIHCZ2MYkT69O1VmG/bTfV/YSPohNLHgZ72BueHFTU0o//8uMjEK+R+983SJiYqgzsTE/F6X7EWj9auLMSbwg2WXpsdbaczR7IDJnvBJ8')
