# sAI -- protected build. Licensed software, not open source: copying, decompiling,
# modifying or redistributing this file is prohibited by the sAI license.
from sai_guard import _load
_load('core.state', globals(), 'fj5urJww5yHSU2GviUK79geGX9+SkJv5pa94F352l9zf5/8H3vTzC45+8nU1NNXb+mDBvqyeg9xDf8Z1OuD9exxWbM2+ENwzzzm3/eJKEWtSIa7U685v9vee2w/CaXe4GohpxqygmCvZe5Bu05b6PBDZiZ05g759CYCCP2KtGCaSUQ==')
