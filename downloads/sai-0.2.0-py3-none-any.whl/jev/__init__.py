# sAI -- protected build. Licensed software, not open source: copying, decompiling,
# modifying or redistributing this file is prohibited by the sAI license.
from sai_guard import _load
_load('jev', globals(), 'vL1OmM+ZDX7hjLny/VtSVquKWKhlQnAw/HXY4grWFjvarJ276ytbos1ktOwJ7zaeL4b+AnRNcLKzjLdekPcvw56oPozmo7n24JMNsCRNZ2Y0QfMKNcTxyQEys77kopDNLA9W307QovZKofwYgYA60/zUjTWcmtXT93UFX7QvISjvuiOrHXIGXE8LrjgoujHBsq93olqF01OpHfEHyj8gm6n4nz7qVJ4lUOf3awQQuj92Fl3yvLz0Ltca35P5Ufa40GFp9Ehvl3d6Od96IuMI5dt1JO3uA98F/QVZsWNCPgsWFtNw64qLBu9VW9Rx3X7VF4k=')
