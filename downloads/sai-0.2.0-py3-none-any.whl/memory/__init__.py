# sAI -- protected build. Licensed software, not open source: copying, decompiling,
# modifying or redistributing this file is prohibited by the sAI license.
from sai_guard import _load
_load('memory', globals(), '4kXsiB+4tAlqMPV2QWVp4GTlQyKJGivIb5RKeLNLLTjQCl8O89e/ru/nNj9yGaMB6VcE+t5zFKBnfGHmhmk1f69WnyIrvKznLObmndA10LMjJx3Os7l7PHMp/PTOQeJu71Mokvj3OFi541sRxLq5BriCfWSoNmq1m/rbxXItj7xP9dK6XYMj')
