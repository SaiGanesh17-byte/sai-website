# sAI -- protected build. Licensed software, not open source: copying, decompiling,
# modifying or redistributing this file is prohibited by the sAI license.
from sai_guard import _load
_load('core.event_bus', globals(), 'fa/DTt2lV7TTjP/XeeGjfO/0QeqelGvU+Md6AbcLw6az7VuDUb/d+Di5Tw7WBnwtzy24ReaZlR0ypYi6IH+bOx/2oIkBmm79kk77arb1QE51PnrrfQi4Oke+nynzKUYm6XUcY4upZ06n3x95rsH51zLcSFvLjBadPhwnqS492F0IMRdkFYzX4SFzYb7zH5MTjeRAV+sjgumsYfYTCo3KyeWwLubyDKuQnbmLg4xx2ttgYVXTLF8EEhQIBeXMn+Hdcf/omlhc3FRX2AW8mBBaAgIljanDBDl/jLUjuinuh/TSLct0Iwm6Gibo2kgbdYht')
