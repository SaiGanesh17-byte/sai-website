"""
sai-guard runtime -- shipped inside protected sAI builds as the `sai_guard` package.

Every protected module is a stub holding encrypted bytecode; this decrypts it in memory
with the build key, which only a valid license unlocks:

  license.json  -- issued by the sAI owner, signed with their Ed25519 key (checked against
                   PUBLIC_KEY below), optionally with an expiry date and locked to one machine.
  build key     -- AES-256-GCM key the modules are encrypted with, stored in the license
                   wrapped under a key derived from the license id -- and, for a machine-locked
                   license, from a code only that machine can compute.

Licensed software, not open source. Decompiling, modifying or redistributing it is
prohibited by the sAI license.
"""
import base64
import datetime
import hashlib
import json
import marshal
import os
import subprocess
import sys
from pathlib import Path

PUBLIC_KEY = "xu665q0lNsYhLi2dKTuTLv0OH0gENTaWGi5X+NGMgk8="
PYTHON = (3, 14)  # filled in at build time: bytecode only runs on the Python it was built with
BUILD_ID = "20261004-210339"

_build_key = None


class LicenseError(ImportError):
    pass


def _raw_machine_id() -> str:
    try:
        if sys.platform == "darwin":
            out = subprocess.run(["ioreg", "-rd1", "-c", "IOPlatformExpertDevice"],
                                 capture_output=True, text=True, timeout=5).stdout
            for line in out.splitlines():
                if "IOPlatformUUID" in line:
                    return line.split('"')[-2]
        elif sys.platform.startswith("linux"):
            for path in ("/etc/machine-id", "/var/lib/dbus/machine-id"):
                if os.path.exists(path):
                    return Path(path).read_text().strip()
        elif sys.platform == "win32":
            out = subprocess.run(["reg", "query", r"HKLM\SOFTWARE\Microsoft\Cryptography", "/v", "MachineGuid"],
                                 capture_output=True, text=True, timeout=5).stdout
            return out.split()[-1]
    except Exception:
        pass
    return ""


def machine_code() -> str:
    """What a user sends the owner to get a license locked to this machine."""
    raw = _raw_machine_id()
    if not raw:
        raise LicenseError("Couldn't identify this machine; ask for a license that isn't machine-locked.")
    return hashlib.sha256(f"sai-guard:{raw}".encode()).hexdigest()


def machine_check(code: str) -> str:
    """Stored in machine-locked licenses: identifies the machine without revealing its code."""
    return hashlib.sha256(f"sai-guard-check:{code}".encode()).hexdigest()[:24]


def license_path() -> Path:
    return Path(os.environ.get("SAI_LICENSE") or Path.home() / ".sai" / "license.json")


def signed_bytes(lic: dict) -> bytes:
    return json.dumps({k: v for k, v in lic.items() if k != "signature"}, sort_keys=True,
                      separators=(",", ":")).encode()


def wrapping_key(lic_id: str, code: str) -> bytes:
    from cryptography.hazmat.primitives import hashes
    from cryptography.hazmat.primitives.kdf.hkdf import HKDF
    return HKDF(algorithm=hashes.SHA256(), length=32, salt=lic_id.encode(),
                info=b"sai-guard build key wrap").derive((code or "any-machine").encode())


def _unlock() -> bytes:
    global _build_key
    if _build_key is not None:
        return _build_key
    path = license_path()
    try:
        lic = json.loads(path.read_text())
    except (OSError, ValueError):
        raise LicenseError(f"No sAI license found at {path}. Activate yours with "
                           f"`python -m sai_guard activate`, or set SAI_LICENSE to its path.") from None
    _build_key = check_license(lic)
    return _build_key


def check_license(lic: dict) -> bytes:
    """The build key this license unlocks; LicenseError if it isn't valid here."""
    from cryptography.exceptions import InvalidSignature, InvalidTag
    from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey
    from cryptography.hazmat.primitives.ciphers.aead import AESGCM
    try:
        Ed25519PublicKey.from_public_bytes(base64.b64decode(PUBLIC_KEY)).verify(
            base64.b64decode(lic.get("signature", "")), signed_bytes(lic))
    except (InvalidSignature, ValueError):
        raise LicenseError("This sAI license isn't valid (it was altered, or not issued for this build).") from None
    expires = lic.get("expires")
    if expires and datetime.date.today() > datetime.date.fromisoformat(expires):
        raise LicenseError(f"This sAI license expired on {expires}.")
    code = ""
    if lic.get("machine"):
        code = machine_code()
        if machine_check(code) != lic["machine"]:
            raise LicenseError("This sAI license is for a different computer.")
    try:
        return AESGCM(wrapping_key(lic["id"], code)).decrypt(
            base64.b64decode(lic["nonce"]), base64.b64decode(lic["wrapped_key"]), lic["id"].encode())
    except (InvalidTag, KeyError, ValueError):
        raise LicenseError("This sAI license can't unlock this build (it belongs to another version).") from None


def find_license(text: str):
    """The first JSON object in `text` that is a license, or None. People paste the whole
    approval email, whose instructions themselves mention "{ to }"."""
    decoder = json.JSONDecoder()
    for start in (i for i, ch in enumerate(text) if ch == "{"):
        try:
            candidate, _ = decoder.raw_decode(text[start:])
        except ValueError:
            continue
        if isinstance(candidate, dict) and "signature" in candidate:
            return candidate
    return None


def activate(text: str) -> Path:
    """Checks a license pasted from the email (surrounding text is ignored) and installs it."""
    lic = find_license(text)
    if lic is None:
        raise LicenseError("That doesn't look like an sAI license -- copy everything from { to } in the email.")
    check_license(lic)
    path = license_path()
    path.parent.mkdir(parents=True, exist_ok=True)
    fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
    with os.fdopen(fd, "w") as f:
        json.dump(lic, f, indent=2)
    return path


def _decrypt(label: str, blob: str) -> bytes:
    from cryptography.exceptions import InvalidTag
    from cryptography.hazmat.primitives.ciphers.aead import AESGCM
    raw = base64.b64decode(blob)
    try:
        return AESGCM(_unlock()).decrypt(raw[:12], raw[12:], label.encode())
    except InvalidTag:
        raise LicenseError(f"Protected part '{label}' is damaged or from another build.") from None


def _load(module: str, namespace: dict, blob: str) -> None:
    if sys.version_info[:2] != tuple(PYTHON):
        raise LicenseError(f"This sAI build runs on Python {PYTHON[0]}.{PYTHON[1]}; "
                           f"you are using {sys.version_info[0]}.{sys.version_info[1]}.")
    # marshal + exec is the point: the payload is this build's own bytecode. AES-GCM
    # authenticates it first, so only code encrypted with the build key gets this far.
    exec(marshal.loads(_decrypt(module, blob)), namespace)


def read_resource(path) -> str:
    """Contents of an encrypted data file (<name>.sgd) -- e.g. an agent's prompt."""
    path = Path(path)
    label = "/".join(path.parts[-3:])  # e.g. agents/configs/coder.yaml.sgd
    return _decrypt(label, path.read_text().strip()).decode("utf-8")
