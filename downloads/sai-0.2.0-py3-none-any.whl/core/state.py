# sAI -- protected build. Licensed software, not open source: copying, decompiling,
# modifying or redistributing this file is prohibited by the sAI license.
from sai_guard import _load
_load('core.state', globals(), 'PWw8wCqyFufwd4fnEveITdad130XCR8f3kgRvJiBm3pd0glDk0beKJCYXykHt37nReYdJyZFwYhY692piyO9a5muhwOedpjMEjfNFJh498GtBOzDufdUErtuTofyU5w9jAn0+fRcKenCHoCewY83iCCqSKfhGmtvIIw2pBLkdr5dZw==')
