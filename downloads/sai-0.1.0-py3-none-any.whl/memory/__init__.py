# sAI -- protected build. Licensed software, not open source: copying, decompiling,
# modifying or redistributing this file is prohibited by the sAI license.
from sai_guard import _load
_load('memory', globals(), 'Tg/MSEfqUYM9EesGEBI1CEq0J4r6kods6rCBJHx/Ss10kVfT0N9NBce8lvlWbZJMobjJ4lBxi4VGFjD0GlVI4x9xE6F3A5SxWGinwjHxt/rwH5ntw3mMbrIcfvZ/VR1StS5A+YfKdWaTOhrW7srybFL/ThnJd4vID6UvGnHR1uNigpD438Wc')
