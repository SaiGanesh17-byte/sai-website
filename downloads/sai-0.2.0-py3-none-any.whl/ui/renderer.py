# sAI -- protected build. Licensed software, not open source: copying, decompiling,
# modifying or redistributing this file is prohibited by the sAI license.
from sai_guard import _load
_load('ui.renderer', globals(), 'eH62I2mJpsT6xEdrgCDQUjGanDsepREx4kSY7fdW4bmPrtHhOtn48CLmS/J29wKNTes8ovpzi/SmNNBl/h+c+hPcIUvTWwrZVpKd+gdSFqI6NFi0jQmztRDC0NbMlfUMvmDEkPpyLUheFEOylV81CaqNIPvG8njBYxWbRdDldlRt8KA=')
