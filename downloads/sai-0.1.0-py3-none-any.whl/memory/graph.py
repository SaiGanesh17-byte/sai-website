# sAI -- protected build. Licensed software, not open source: copying, decompiling,
# modifying or redistributing this file is prohibited by the sAI license.
from sai_guard import _load
_load('memory.graph', globals(), 'qyCb7qhCNVpQZNDGAAMDFi9zJLoz1gk68DhDH9RL8vbNKr5GpBKxHwyDwCOX4U+EROxqT45PL6LIBNvZdh4dTegujnYVV5UVbjpRLy++m+FG4y9CMBpkoAP+GaeX8gjr3llXhVoC2QxkiPVu4ThzOJP5t9u4xQM4DkQpP1SvxD6kdIHB')
