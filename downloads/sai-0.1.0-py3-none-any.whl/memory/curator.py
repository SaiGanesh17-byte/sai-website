# sAI -- protected build. Licensed software, not open source: copying, decompiling,
# modifying or redistributing this file is prohibited by the sAI license.
from sai_guard import _load
_load('memory.curator', globals(), 'Jl93w4b2MDZqQPkrlkn9sBdoYpGRJm1ojvc0hfT1TzD7rTs4rI8iGZqr4FGbkhXP3NIU+VeydcAxiOrLqH1mXqO9zvnJxRGxhsUw4oDhcM2bidBO03JC2EhwBFEEBQkXDYlKyCLXwHaB2NYmnuLMFbInR3+hQOUDIsPRaKv3axKXDIhPLMg=')
