# sAI -- protected build. Licensed software, not open source: copying, decompiling,
# modifying or redistributing this file is prohibited by the sAI license.
from sai_guard import _load
_load('ui', globals(), 'YwgnvDs+f5x0L9wTi6aXRBApH06SKBkM1KXcALIEk34RTuSL5vIrg/nY3/sE/5anIYCPEASNHJgL3GofdC8+6VN0RZBJb4kM+TNn5S5oKDXvZtFRRdI9kB+rI9zpVidlG8kv6rJixVGJZ3VkxSNdduhH3KLsHDsVNJQV9fxO/HO0ZrM=')
