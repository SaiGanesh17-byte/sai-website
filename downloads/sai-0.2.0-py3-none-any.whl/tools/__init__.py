# sAI -- protected build. Licensed software, not open source: copying, decompiling,
# modifying or redistributing this file is prohibited by the sAI license.
from sai_guard import _load
_load('tools', globals(), 'Zpr7H2Za0QF/fAzncgjB9IaEovvwAMsr/wup+rFK4OkGPs2lY5wud57F5pK1+zwoOyg1G4YAxWA/lae3ZY2V/SZY0bcevnVrhMxQ2Ylf4Bcu3H6OByXVbRb+gKVTKZn7ua11HcyRRIMWh3uwY3mef3B4WLhRK5BN7lVchaOEwzstQKdRZLM=')
